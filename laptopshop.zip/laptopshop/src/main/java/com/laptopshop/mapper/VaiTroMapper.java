package com.laptopshop.mapper;

public class VaiTroMapper {

}
