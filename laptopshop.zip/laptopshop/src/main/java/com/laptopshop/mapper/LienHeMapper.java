package com.laptopshop.mapper;

public class LienHeMapper {

}
