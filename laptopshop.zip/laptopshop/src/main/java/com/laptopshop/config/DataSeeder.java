package com.laptopshop.config;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.laptopshop.entities.NguoiDung;
import com.laptopshop.entities.VaiTro;
import com.laptopshop.repository.NguoiDungRepository;
import com.laptopshop.repository.VaiTroRepository;

@Component
public class DataSeeder implements ApplicationListener<ContextRefreshedEvent> {

	

	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		
	
		
	}
}
